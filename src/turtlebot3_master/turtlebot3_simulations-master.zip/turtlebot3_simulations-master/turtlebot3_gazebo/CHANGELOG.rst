^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
Changelog for package turtlebot3_gazebo_ros
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

0.2.4 (2018-03-14)
-----------
* none

0.2.3 (2018-03-14)
-----------
* solved DuplicateVersionsException error
* Contributors: Pyo

0.2.2 (2018-03-14)
-----------
* none

0.2.1 (2018-03-14)
-----------
* added worlds for gazebo and turtlebot3
* Contributors: Darby Lim

0.2.0 (2018-03-13)
-----------
* added slam with multiple tb3
* added multi example
* added turtlebot3_house
* modified cmake file
* modified spwn model name
* modified multi slam param
* modified camera position
* modified folder name
* Contributors: Darby Lim

0.1.7 (2017-08-16)
-----------
* renamed missed the install rule (worlds -> models)
* Contributors: Darby Lim, Tully Foote

0.1.6 (2017-08-14)
-----------
* modified folder name and model path
* updated rviz and add static tf publisher for depth camera
* Contributors: Darby Lim

0.1.5 (2017-06-09)
-----------
* modified make files for dependencies
* updated turtlebot3 sim
* updated world config
* Contributors: Darby Lim

0.1.4 (2017-05-23)
-----------
* added as new meta-packages and version update (0.1.4)
* Contributors: Darby Lim, Pyo
